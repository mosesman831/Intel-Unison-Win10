const q = (id) => document.getElementById(id);
const updateStateManager = window.MSStoreActions;
let state = 'Checking';
const themeManager = window.AppThemeManager;
const logger = window.Logger;
const error = text => logger.log(4, `ComingSoon ${text}`);
const debug = text => logger.log(1, `ComingSoon ${text}`);

const start = async () => {
  updateState();
  checkStatus();
  if (themeManager) {
    themeManager.setTitleBarTheme('#202020', '#FFFFFF', '#FFFFFF');
  }
  if (updateStateManager) {
    updateStateManager.ondownloadprogress = updateProgressValue;
  }
};

const checkStatus = async () => {
  debug(`checkStatus`);
  try {
    const hasUpdate = await updateStateManager.checkForAvailableUpdates();
    debug(`checkStatus hasUpdate=${hasUpdate}`);
    setState(hasUpdate ? 'Available' : 'NotAvailable');
    updateState();
  } catch (e) {
    error(`checkStatus failed=${e}`);
    setState('Failure');
  }
}
const updateProgressValue = (e) => {
  setUpdateProgress(Math.floor(e.target * 100));
};
const updateState = () => {
  updateComponent();
  loadStrings();
}
const updateComponent = () => {
  document.getElementById('component').innerHTML = getComponent();
}
const loadStrings = () => {
  setString('title', state === 'NotAvailable' ? 'ComingSoon' : 'ProductName');
  setString('terms', 'TermsOfService');
  setString('privacy', 'PrivacyPolicy');
  setString('termsTitle', 'TermsTitle');
  setString('pleaseWait', 'PleaseWait');
  setString('notAvailableTitle', 'ComingSoonUnavailable');
  setString('availableTitle', 'ComingSoonUpdateSubtitle');
  setString('updateButton', 'ComingSoonUpdateButton');
  setString('retryButton', 'TryAgain');
  setString('subtitleWithFailure', 'ComingSoonFailed');
  setString('subtitleUpdating', 'ComingSoonUpdating');
};

const setString = (id, stringPath) => {
  if (q(id)) q(id).innerText = getString(stringPath);
}
const getComponent = () => {
  switch (state) {
    case ('Checking'): return templateChecking();
    case ('NotAvailable'): return templateNotAvailable();
    case ('Available'): return templateAvailable();
    case ('Updating'): return templateUpdating();
    case ('Failure'): return templateFailure();
    default: return NotAvailable();
  }
}
const getString = (path) => {
  return window.ResourceProvider.getString(path);
};

const updateContainer = async () => {
  debug(`updateContainer`);
  setState('Updating');
  let updateRes;
  try {
    updateRes = await updateStateManager.tryUpdate();
  } catch (e) {
    error(`updateContainer failed=${e}`);
  }
  // Cancelled
  if (updateRes == 4) {
    debug(`updateContainer cancelled`);
    setState('Available');
    return;
  }
  // On a successful update this line shouldn't be reached
  debug(`updateContainer res=${updateRes}`);
  setState('Failure');
};

const setState = (newState) => {
  state = newState;
  updateState();
}

const setUpdateProgress = (progress) => {
  if (!q('progress') || !q('updatingPercentage') || !q('progressBar')) return;
  q('updatingPercentage').innerText = progress;
  q('progress').style = `transform: translateX(-${100 - progress}%)`;
}

function templateChecking () {
  return `
  <div class='infoWrapper'>
    <div class='subtitle flex'>
      <div class='spinnerWrapper'>
      <svg class='spinner' viewBox='0 0 50 50'>
        <circle class='pathbg' cx='25' cy='25' r='20' fill='none' stroke='inherit' stroke-width='7'/>
        <circle class='path' cx='25' cy='25' r='20' fill='none' stroke-width='7'/>
      </svg>
      </div><div id='pleaseWait'></div>
    </div>
  </div>
  `;
}

function templateNotAvailable () {
  return `
  <div class='infoWrapper'>
    <div id='notAvailableTitle' class='subtitle'></div>
  </div>
  `
}

function templateAvailable () {
  return `
  <div class='infoWrapper'>
    <div id='availableTitle' class='subtitle'></div>
    <button id='updateButton' class='button' onclick='updateContainer()'></button>
  </div>
  `
}

function templateUpdating () {
  return `
  <div class='infoWrapper'>
  <div class='updating'>
    <div id='progressBar' class='progressBar'><span id='progress' class='progress'></span></div>
    <div class='subtitle flex'>
      <div id='subtitleUpdating'></div>&nbsp;<div id='updatingPercentage' class='updatingPercentage'>0</div>%
    </div>
  </div>
  </div>
`
}
function templateFailure () {
  return `
  <div class='infoWrapper'>
    <div id='subtitleWithFailure' class='subtitle'></div>
    <button id='retryButton' class='button' onclick='updateContainer()'></button>
  </div>
  `
}

start();
